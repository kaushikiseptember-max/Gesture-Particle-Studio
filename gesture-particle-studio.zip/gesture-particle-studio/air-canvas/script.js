(function () {
  'use strict';

  const COLORS = ['#22e8ff','#ff2bd6','#ff8a1e','#d6ff2b','#2bff8f','#9d6bff','#ffffff','#ff3b3b'];

  const drawLayer = document.getElementById('drawLayer');
  const dctx = drawLayer.getContext('2d');
  const fxLayer = document.getElementById('fxLayer');
  const fctx = fxLayer.getContext('2d');

  function fitCanvas(cv, ctx, preserve) {
    const prev = preserve ? cv.toDataURL() : null;
    const dpr = window.devicePixelRatio || 1;
    cv.width = window.innerWidth * dpr;
    cv.height = window.innerHeight * dpr;
    cv.style.width = window.innerWidth + 'px';
    cv.style.height = window.innerHeight + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (prev) { const img = new Image(); img.onload = () => ctx.drawImage(img, 0, 0, window.innerWidth, window.innerHeight); img.src = prev; }
  }
  fitCanvas(drawLayer, dctx, false);
  fitCanvas(fxLayer, fctx, false);
  window.addEventListener('resize', () => { fitCanvas(drawLayer, dctx, true); fitCanvas(fxLayer, fctx, false); });

  // ---------------------------------------------------------------------
  // TOOL STATE
  // ---------------------------------------------------------------------
  const tool = { color: '#22e8ff', shape: 'line', size: 6, font: "Georgia, serif" };
  let pendingText = null; // { text } waiting to be placed

  const colorGroup = document.getElementById('colorGroup');
  COLORS.forEach((c, i) => {
    const el = document.createElement('div');
    el.className = 'swatch' + (i === 0 ? ' active' : '');
    el.style.background = c;
    el.addEventListener('click', () => {
      tool.color = c;
      document.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
      el.classList.add('active');
    });
    colorGroup.appendChild(el);
  });
  document.getElementById('customColor').addEventListener('input', (e) => {
    tool.color = e.target.value;
    document.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
  });

  document.querySelectorAll('.toolBtn[data-shape]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.toolBtn[data-shape]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      tool.shape = btn.dataset.shape;
    });
  });

  document.getElementById('fontSelect').addEventListener('change', (e) => { tool.font = e.target.value; });
  document.getElementById('sizeSlider').addEventListener('input', (e) => { tool.size = parseInt(e.target.value, 10); });

  document.getElementById('textBtn').addEventListener('click', () => {
    const txt = window.prompt('Enter text to place (click/point on the canvas next to place it):');
    if (txt && txt.trim()) pendingText = { text: txt.trim() };
  });

  document.getElementById('clearBtn').addEventListener('click', () => {
    dctx.clearRect(0, 0, drawLayer.width, drawLayer.height);
  });

  document.getElementById('saveBtn').addEventListener('click', () => {
    const link = document.createElement('a');
    link.download = 'air-canvas.png';
    link.href = drawLayer.toDataURL('image/png');
    link.click();
  });

  const video = document.getElementById('video');
  const cameraBtn = document.getElementById('cameraBtn');
  let camVisible = true;
  cameraBtn.addEventListener('click', () => {
    camVisible = !camVisible;
    video.classList.toggle('hidden', !camVisible);
  });

  // ---------------------------------------------------------------------
  // DRAWING PRIMITIVES
  // ---------------------------------------------------------------------
  let lastX = null, lastY = null;

  function drawLine(x, y, color, size) {
    if (lastX !== null) {
      dctx.save();
      dctx.strokeStyle = color; dctx.shadowColor = color; dctx.shadowBlur = size * 1.4;
      dctx.lineWidth = size; dctx.lineCap = 'round'; dctx.lineJoin = 'round';
      dctx.beginPath(); dctx.moveTo(lastX, lastY); dctx.lineTo(x, y); dctx.stroke();
      dctx.restore();
    }
    lastX = x; lastY = y;
  }

  function stampHeart(x, y, size, color) {
    const s = size * 1.6;
    dctx.save();
    dctx.translate(x, y); dctx.fillStyle = color; dctx.shadowColor = color; dctx.shadowBlur = size;
    dctx.beginPath();
    dctx.moveTo(0, s * 0.3);
    dctx.bezierCurveTo(0, 0, -s, 0, -s, s * 0.35);
    dctx.bezierCurveTo(-s, s * 0.75, -s * 0.4, s * 1.0, 0, s * 1.35);
    dctx.bezierCurveTo(s * 0.4, s * 1.0, s, s * 0.75, s, s * 0.35);
    dctx.bezierCurveTo(s, 0, 0, 0, 0, s * 0.3);
    dctx.closePath(); dctx.fill();
    dctx.restore();
  }

  function stampFlower(x, y, size, color) {
    const s = size * 1.1, petals = 6;
    dctx.save();
    dctx.translate(x, y); dctx.fillStyle = color; dctx.globalAlpha = 0.85; dctx.shadowColor = color; dctx.shadowBlur = size;
    for (let i = 0; i < petals; i++) {
      dctx.save();
      dctx.rotate((Math.PI * 2 / petals) * i);
      dctx.beginPath();
      dctx.ellipse(0, s * 0.65, s * 0.4, s * 0.65, 0, 0, Math.PI * 2);
      dctx.fill();
      dctx.restore();
    }
    dctx.globalAlpha = 1;
    dctx.fillStyle = '#fff8d6';
    dctx.beginPath(); dctx.arc(0, 0, s * 0.32, 0, Math.PI * 2); dctx.fill();
    dctx.restore();
  }

  function stampStar(x, y, size, color) {
    const spikes = 5, outer = size * 1.4, inner = size * 0.6;
    dctx.save();
    dctx.translate(x, y); dctx.fillStyle = color; dctx.shadowColor = color; dctx.shadowBlur = size;
    let rot = Math.PI / 2 * 3;
    const step = Math.PI / spikes;
    dctx.beginPath();
    dctx.moveTo(0, -outer);
    for (let i = 0; i < spikes; i++) {
      dctx.lineTo(Math.cos(rot) * outer, Math.sin(rot) * outer); rot += step;
      dctx.lineTo(Math.cos(rot) * inner, Math.sin(rot) * inner); rot += step;
    }
    dctx.closePath(); dctx.fill();
    dctx.restore();
  }

  function placeText(x, y, text, font, size, color) {
    dctx.save();
    dctx.font = `${Math.max(16, size * 3)}px ${font}`;
    dctx.fillStyle = color; dctx.shadowColor = color; dctx.shadowBlur = 10;
    dctx.textBaseline = 'middle';
    dctx.fillText(text, x, y);
    dctx.restore();
  }

  let lastStampAt = 0;
  function handleDrawPoint(x, y) {
    if (pendingText) {
      placeText(x, y, pendingText.text, tool.font, tool.size, tool.color);
      pendingText = null;
      return;
    }
    if (tool.shape === 'line') {
      drawLine(x, y, tool.color, tool.size);
    } else {
      const now = performance.now();
      if (now - lastStampAt > 90) {
        lastStampAt = now;
        if (tool.shape === 'heart') stampHeart(x, y, tool.size, tool.color);
        else if (tool.shape === 'flower') stampFlower(x, y, tool.size, tool.color);
        else if (tool.shape === 'star') stampStar(x, y, tool.size, tool.color);
      }
    }
  }
  function breakStroke() { lastX = null; lastY = null; }

  function eraseAt(x, y, radius) {
    dctx.save();
    dctx.globalCompositeOperation = 'destination-out';
    dctx.beginPath(); dctx.arc(x, y, radius, 0, Math.PI * 2); dctx.fill();
    dctx.restore();
  }

  // ---------------------------------------------------------------------
  // MOUSE / TOUCH FALLBACK (always available, reliable)
  // ---------------------------------------------------------------------
  let mouseDown = false;
  drawLayer.addEventListener('mousedown', (e) => {
    mouseDown = true;
    handleDrawPoint(e.clientX, e.clientY);
  });
  drawLayer.addEventListener('mousemove', (e) => {
    if (mouseDown) handleDrawPoint(e.clientX, e.clientY);
  });
  window.addEventListener('mouseup', () => { mouseDown = false; breakStroke(); });

  drawLayer.addEventListener('touchstart', (e) => {
    const t = e.touches[0]; handleDrawPoint(t.clientX, t.clientY); e.preventDefault();
  }, { passive: false });
  drawLayer.addEventListener('touchmove', (e) => {
    const t = e.touches[0]; handleDrawPoint(t.clientX, t.clientY); e.preventDefault();
  }, { passive: false });
  drawLayer.addEventListener('touchend', () => breakStroke());

  // ---------------------------------------------------------------------
  // HAND TRACKING
  // ---------------------------------------------------------------------
  const statusEl = document.getElementById('status');
  const statusText = document.getElementById('statusText');

  function dist3(a, b) { return Math.hypot(a.x - b.x, a.y - b.y, (a.z || 0) - (b.z || 0)); }

  function analyzeHand(lm) {
    const wrist = lm[0];
    const map = { thumb: [4, 3], index: [8, 6], middle: [12, 10], ring: [16, 14], pinky: [20, 18] };
    const ext = {}; let count = 0;
    for (const k in map) {
      const [tip, pip] = map[k];
      const e = dist3(wrist, lm[tip]) > dist3(wrist, lm[pip]) * 1.12;
      ext[k] = e; if (e) count++;
    }
    return { ext, count };
  }

  const FIST_HOLD_MS = 1100;
  const POINT_MISS_TOLERANCE = 5; // frames of momentary misdetection to bridge over, so letters don't get gaps

  // handState is written by onResults (MediaPipe's own, slower, irregular rate)
  // and consumed every screen frame by the render loop below. Separating the
  // two is what fixes "late" / "jagged" strokes: MediaPipe only updates
  // ~15-20x/sec, which is too coarse for smooth cursive letter shapes on its own.
  const handState = {
    present: false,
    gesture: 'none',   // 'point' | 'erase' | 'fist' | 'none'
    rawX: 0, rawY: 0,
    missFrames: 0
  };

  function onResults(results) {
    const hands = results.multiHandLandmarks || [];
    if (hands.length === 0) {
      handState.present = false;
      handState.gesture = 'none';
      return;
    }
    handState.present = true;
    const lm = hands[0];
    const { ext, count } = analyzeHand(lm);

    if (count === 0) {
      const palmX = (1 - lm[9].x) * window.innerWidth, palmY = lm[9].y * window.innerHeight;
      handState.gesture = 'fist';
      handState.rawX = palmX; handState.rawY = palmY;
      handState.missFrames = 0;
      return;
    }

    if (count >= 4) {
      const palmX = (1 - lm[9].x) * window.innerWidth, palmY = lm[9].y * window.innerHeight;
      handState.gesture = 'erase';
      handState.rawX = palmX; handState.rawY = palmY;
      handState.missFrames = 0;
      return;
    }

    if (ext.index && !ext.middle && !ext.ring && !ext.pinky) {
      const mirrorX = 1 - lm[8].x, mirrorY = lm[8].y;
      handState.gesture = 'point';
      handState.rawX = mirrorX * window.innerWidth;
      handState.rawY = mirrorY * window.innerHeight;
      handState.missFrames = 0;
      return;
    }

    // ambiguous frame: if we were mid-stroke, bridge over it briefly instead
    // of breaking the letter (finger shape flickers a little during fast cursive motion)
    if (handState.gesture === 'point' && handState.missFrames < POINT_MISS_TOLERANCE) {
      handState.missFrames++;
    } else {
      handState.gesture = 'none';
    }
  }

  const hands = new Hands({ locateFile: (file) => 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/' + file });
  hands.setOptions({ maxNumHands: 1, modelComplexity: 0, minDetectionConfidence: 0.6, minTrackingConfidence: 0.5 });
  hands.onResults(onResults);

  const mpCamera = new Camera(video, {
    onFrame: async () => { await hands.send({ image: video }); },
    width: 480, height: 360
  });
  mpCamera.start().then(() => {
    statusText.textContent = 'Tracking';
    statusEl.classList.add('live');
  }).catch(() => {
    statusText.textContent = 'Camera off — use mouse/touch';
  });

  // ---------------------------------------------------------------------
  // SMOOTHING RENDER LOOP (runs every screen frame, ~60fps)
  // ---------------------------------------------------------------------
  function drawClearProgress(x, y, level) {
    fctx.clearRect(0, 0, fxLayer.width, fxLayer.height);
    if (level <= 0) return;
    fctx.save();
    fctx.lineWidth = 4; fctx.strokeStyle = 'rgba(255,255,255,0.2)';
    fctx.beginPath(); fctx.arc(x, y, 30, 0, Math.PI * 2); fctx.stroke();
    fctx.strokeStyle = '#ff5050'; fctx.shadowColor = '#ff5050'; fctx.shadowBlur = 10;
    fctx.beginPath(); fctx.arc(x, y, 30, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * level); fctx.stroke();
    fctx.restore();
  }

  let smoothX = 0, smoothY = 0, smoothInit = false;
  let eraseX = 0, eraseY = 0, eraseInit = false;
  let fistStart = null;
  let lastGesture = 'none';

  function gestureRenderLoop() {
    requestAnimationFrame(gestureRenderLoop);
    const g = handState.gesture;

    if (g !== 'fist') { fistStart = null; if (lastGesture === 'fist') fctx.clearRect(0, 0, fxLayer.width, fxLayer.height); }
    if (g !== 'erase') eraseInit = false;

    if (g === 'point') {
      if (!smoothInit) { smoothX = handState.rawX; smoothY = handState.rawY; smoothInit = true; }
      // responsive smoothing: enough to erase jitter, not enough to feel laggy
      smoothX += (handState.rawX - smoothX) * 0.6;
      smoothY += (handState.rawY - smoothY) * 0.6;
      handleDrawPoint(smoothX, smoothY);
    } else {
      smoothInit = false;
      breakStroke();
    }

    if (g === 'erase') {
      if (!eraseInit) { eraseX = handState.rawX; eraseY = handState.rawY; eraseInit = true; }
      eraseX += (handState.rawX - eraseX) * 0.5;
      eraseY += (handState.rawY - eraseY) * 0.5;
      eraseAt(eraseX, eraseY, tool.size * 3 + 20);
    }

    if (g === 'fist') {
      if (fistStart === null) fistStart = performance.now();
      const level = Math.min(1, (performance.now() - fistStart) / FIST_HOLD_MS);
      drawClearProgress(handState.rawX, handState.rawY, level);
      if (level >= 1) {
        dctx.clearRect(0, 0, drawLayer.width, drawLayer.height);
        fistStart = null;
        fctx.clearRect(0, 0, fxLayer.width, fxLayer.height);
      }
    }

    lastGesture = g;
  }
  gestureRenderLoop();
})();
