# Gesture Particle Studio

Two browser-based, hand-gesture-controlled experiences built with **Three.js** and **MediaPipe Hands** — no frameworks, no build step, just open an HTML file.

1. **Spherical Magic** — a 3D particle sphere (3,000 particles) that you move, rotate, resize, recolor, and explode with your hands in front of a webcam.
2. **Air Canvas** — draw in mid-air with your fingertip: pick colors, brush shapes (heart, flower, star), fonts, erase with an open palm, and clear with a held fist.

## Live Demo

Once GitHub Pages is enabled for this repo (Settings → Pages → branch `main`, folder `/root`), your apps will be live at:

- `https://kaushikiseptember-max.github.io/gesture-particle-studio/spherical-magic/`
- `https://kaushikiseptember-max.github.io/gesture-particle-studio/air-canvas/`

## Why two separate files?

Both use webcam hand-tracking, but their gestures conflict if combined (e.g. the sphere's two-hand zoom gesture fights with fingertip drawing). Splitting them into two focused single-page apps keeps each one responsive and predictable.

## Tech Stack

| Piece | What it does |
|---|---|
| **Three.js (r128)** | Renders the 3D particle sphere, handles the WebGL scene, camera, and additive-blended glowing particles |
| **MediaPipe Hands** | Google's on-device hand-landmark model — detects up to 21 3D points per hand, in real time, entirely in the browser |
| **MediaPipe Camera Utils** | Feeds webcam frames into the Hands model at a steady rate |
| **HTML5 Canvas 2D API** | Draws the charge ring, the fingertip trail/stamps in Air Canvas, and UI overlays |
| **Vanilla JavaScript** | All gesture logic, state machines, and animation — no React, no build tools |
| **CSS3** | Dark minimal UI, glassmorphism panels, transitions |

Everything is loaded from CDNs (`cdnjs`, `jsdelivr`) inside a single HTML file each — there is nothing to `npm install`.

## Running Locally

Browsers block webcam access on `file://` pages, so you need to serve the files, not just double-click them:

```bash
cd gesture-particle-studio
python3 -m http.server 8000
```

Then open `http://localhost:8000/spherical-magic/` or `http://localhost:8000/air-canvas/`.

(This step isn't needed once it's live on GitHub Pages — HTTPS pages get camera access automatically.)

## Spherical Magic — Gestures

| Gesture | Effect |
|---|---|
| One hand, move around | Moves and rotates the sphere |
| Two hands, spread apart / bring together | Grows / shrinks the sphere |
| Pinch (thumb + index) and hold | Fills a charge ring |
| Release pinch at full charge | Particles explode outward, then reform |
| Peace sign (✌️) | Triggers a white shockwave pulse |
| Fist | Freezes the sphere in place |
| Open hand, 5 fingers | Continuous rainbow color cycle |
| 0–4 fingers | Sets particle color from a fixed vibrant palette |
| "Webcam BG" button | Toggles the camera feed as a fullscreen background |

## Air Canvas — Gestures & Controls

| Gesture / Control | Effect |
|---|---|
| Point (index finger only) | Draws / stamps the selected shape |
| Open palm | Erases under your palm |
| Hold a fist (~1s) | Clears the entire canvas |
| Mouse / touch | Draw the same way, no camera needed — the reliable fallback |
| Color swatches / custom color picker | Sets brush/stamp color |
| Brush shape buttons | Freehand line, heart, flower, or star stamp |
| Font dropdown + "Text" button | Type text, then click/point where to place it |
| Size slider | Brush / stamp / eraser size |
| Camera, Clear, Download buttons | Toggle webcam visibility, wipe canvas, save your drawing as PNG |

## File Structure

```
gesture-particle-studio/
├── spherical-magic/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── air-canvas/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── README.md
└── HOW-I-BUILT-THIS.md    # Process write-up
```

## Known Limitations

- Works best in Chrome or Edge; some privacy-hardened browsers restrict camera/WebGL behavior differently.
- Needs reasonable, even lighting for reliable hand tracking.
- Single-hand gestures use the first detected hand; MediaPipe's hand ordering can occasionally swap between frames.

## License

MIT — free to use, modify, and share.
